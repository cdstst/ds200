Scatter plot:
Sources:
https://data.gov.in/catalog/gross-value-added-economic-activity
Description and observation:
Scatter plot of Gross Value (In crores) Added by Economic Activity at Current Prices and Constant Prices for 2014-2015. High correlation between gross values at current price and constant price.

Box plot:
Sources:
https://data.gov.in/resources/air-quality-respect-respirable-suspended-particulate-matterrspm-air-quality-stations-und-0
Description and observation:
States having information of RSPM for 10 areas are filtered and box plot for each state is in the plot. It can be concluded that Delhi RSPM median is lowest and opposite for Karnataka to the data taken.

Bar Plot:
Sources:
https://data.gov.in/resources/air-quality-respect-respirable-suspended-particulate-matterrspm-air-quality-stations-und-0
Description and observation:
Different areas of Hyderabad's RSPM values are plotted as Bar Plot. Charminar has highest RSPM where as Nacharam has lowest.
